import { RECEIVE_API_DATA, RECEIVE_DETAIL_PERSON } from "../actions/actions";


const setApiData = (state, payload) =>{
  return payload;
}
const setDetailPerson =(state, payload) =>{
  return payload;
}

const handlers = {
  [RECEIVE_API_DATA]: setApiData,
  [RECEIVE_DETAIL_PERSON]: setDetailPerson,
};

export default (state = {}, { type, payload }) => {
  return handlers[type] ? handlers[type](state, payload) : state;
};