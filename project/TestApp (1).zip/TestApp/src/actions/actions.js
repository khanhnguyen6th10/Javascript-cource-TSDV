export const REQUEST_API_DATA = "REQUEST_API_DATA";
export const RECEIVE_API_DATA = "RECEIVE_API_DATA";
export const POST_API_DATA = "POST_API_DATA";
export const DELETE_API_DATA = "DELETE_API_DATA";
export const DETAIL_API_DATA = "DETAIL_API_DATA";
export const RECEIVE_DETAIL_DATA = "RECEIVE_DETAIL_DATA";
export const UPDATE_API_DATA = "UPDATE_API_DATA";
export const GET_DETAIL_PERSON = "GET_DETAIL_PERSON";
export const RECEIVE_DETAIL_PERSON = "RECEIVE_DETAIL_PERSON";

export const requestApiData = () => ({ type: REQUEST_API_DATA });
export const receiveApiData = data => ({ type: RECEIVE_API_DATA, payload: data });
export const receiveDetailPerson = data => ({ type: RECEIVE_DETAIL_PERSON, payload: data });
export const postApiData = (data) => ({ 
    type: POST_API_DATA ,
    payload: data
});

export const getDetailPerson = (data) =>({
    type: GET_DETAIL_PERSON,
    payload: data
})

export const deleteApiData = (data) => ({ 
    type: DELETE_API_DATA ,
    payload: data
});

export const detailApiData = (data) => ({ 
    type: DETAIL_API_DATA ,
    payload: data
});

export const receiveDetailData = (data) => ({ 
    type: RECEIVE_DETAIL_DATA ,
    payload: data
});

export const updateApiData = (data) => ({ 
    type: UPDATE_API_DATA ,
    payload: data
});
