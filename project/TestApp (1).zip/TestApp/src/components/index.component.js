import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect } from 'react';
import { connect } from "react-redux";
import { Link } from 'react-router-dom';
import { deleteApiData, requestApiData } from "../actions/actions";


const Index = (props) => {
        const { data, requestApiData, deleteApiData } = props;

    const handleDelete = (id) => () => {
        deleteApiData(id);
    }

    useEffect(() => {
       requestApiData();
    }, [requestApiData]);

    

    return (data && data.length)
        ? <div >
            <h1>List Data Table</h1>
            <table className="table table-striped" style={{ marginTop: 20 }}>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Company</th>
                        <th>Age</th>
                    </tr>
                </thead>
                <tbody >
                    {data.map((x, i) =>
                        <tr key={x._id}>
                            <td>{x.name}</td>
                            <td>{x.company}</td>
                            <td>{x.age}</td>
                            <td>
                                <button onClick={handleDelete(x._id)} className="btn btn-danger">Delete</button>
                            </td>
                            <td>
                                <Link to={"/edit/" + x._id} className="btn btn-primary" >Edit</Link>
                            </td>
                        </tr>)}
                </tbody>
            </table>
        </div>
        : <h1>loading...</h1>;
}



const mapStateToProps = state => ({ data: state.data });

const mapDispatchToProps = {
    requestApiData,
    deleteApiData
}

export default connect(mapStateToProps, mapDispatchToProps)(Index);