import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useState } from 'react';
import { connect } from "react-redux";
import { detailApiData, getDetailPerson, requestApiData, updateApiData } from "../actions/actions";


const Edit = (props) => {
    const { data, updateApiData, getDetailPerson } = props;
    const [dataPerson, setDataPerson] = useState({});
    
    useEffect(() => {
        getDetailPerson(props.match.params.id);
    },[])

    useEffect(() => {
        setDataPerson(data);
    },[data])

    const onChangeData = (e) => {
        const ele = e.target;
        setDataPerson({
            ...dataPerson,
            [ele.title]: ele.value,
        })
    };

    const handleOnsubmit = () => {
        const dataUpdate = {
            ...dataPerson,
            id: props.match.params.id,
        };
        console.log(dataUpdate);
        updateApiData(dataUpdate);
        props.history.push('/index');
    }

  

    return (
        <div style={{ marginTop: 10 }}>
            <h3 align="center">Update Person Info</h3>
            <form onSubmit={handleOnsubmit}>
                <div className="form-group">
                    <label>Person Name:  </label>
                    <input
                        type="text"
                        className="form-control"
                        title="name"
                        value={dataPerson.name || ''}
                        onChange={onChangeData}
                    />
                </div>
                <div className="form-group">
                    <label>Company Name: </label>
                    <input type="text"
                        className="form-control"
                        title="company"
                        value={dataPerson.company || ''}
                        onChange={onChangeData}
                    />
                </div>
                <div className="form-group">
                    <label>Age: </label>
                    <input type="text"
                        className="form-control"
                        title="age"
                        value={dataPerson.age || ''}
                        onChange={onChangeData}
                    />
                </div>
                <div className="form-group">
                    <input type="submit"
                        value="Update Person Info"
                        className="btn btn-primary" />
                </div>
            </form>
        </div>
    )
}
const mapStateToProps = state => ({ data: state.data });

const mapDispatchToProps = {
    requestApiData,
    detailApiData,
    updateApiData,
    getDetailPerson
}

export default connect(mapStateToProps, mapDispatchToProps)(Edit);