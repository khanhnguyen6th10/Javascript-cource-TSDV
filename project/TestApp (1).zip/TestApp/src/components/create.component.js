import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';
import { connect } from "react-redux";
import { postApiData } from "../actions/actions";


const PERSON = {
    name: "",
    company: "",
    age: "",
};

const Create = (props) => {
    const { data, postApiData } = props;
    const [dataPerson, setDataPerson] = useState(PERSON);

    const handleSubmit = () => {
        const dataSubmit = {...dataPerson};
        postApiData(dataSubmit);
        setDataPerson(PERSON);
    }

    const changeData = (e) => {
        const el = e.target;
        setDataPerson({
            ...dataPerson,
            [el.title]: el.value,
        });
    }

    return (
        <div style={{ marginTop: 10 }}>
            <h3>Add New Person</h3>
                <div className="form-group">
                    <label>Person Name: </label>
                    <input 
                        type="text" 
                        required
                        className="form-control"
                        value={dataPerson.name}
                        title="name"
                        onChange={changeData}
                    />
                </div>
                <div className="form-group">
                    <label>Company Name: </label>
                    <input 
                        type="text" 
                        required 
                        className="form-control"
                        title="company" 
                        value={dataPerson.company}
                        onChange={changeData} 
                    />
                </div>
                <div className="form-group">
                    <label>Age: </label>
                    <input 
                        type="text" 
                        required 
                        className="form-control"
                        title="age" 
                        value={dataPerson.age}
                        onChange={changeData}  
                    />
                </div>
                <div className="form-group">
                    <button 
                        className="btn btn-primary"
                        onClick={handleSubmit}
                    >
                        Register Person
                    </button>
                </div>
        </div>)
}
const mapStateToProps = state => ({ data: state.data });

const mapDispatchToProps = {
    postApiData
}

export default connect(mapStateToProps, mapDispatchToProps)(Create);