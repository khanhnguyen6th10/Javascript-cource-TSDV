export const fetchData = async () => {
  try {
    const response = await fetch("http://localhost:4000/persons");
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const fetchDetailPerson = async (objID) => {
  try {
    const response = await fetch(`http://localhost:4000/persons/${objID}`);
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const fetchPostData = async (obj) => {
  try {
    const response = await fetch("http://localhost:4000/persons/add", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(obj)
    });
    console.log(999, response);
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const fetchDeleteData = async (objID) => {
  try {
    const response = await fetch(`http://localhost:4000/persons/delete/${objID}`, {
      method: 'DELETE'
    });
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const fetchDetailData = async (objID) => {
  try {
    const response = await fetch(`http://localhost:4000/persons/edit/${objID}`);
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const fetchUpdateData = async (obj) => {
  try {
    const response = await fetch(`http://localhost:4000/persons/update/${obj.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(obj)
    });
    const data = await response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};