const express = require('express');
const personRoutes = express.Router();


let Person = require('./persons.model');


personRoutes.route('/add').post((req, res) =>{
    let person = new Person(req.body);
    person.save()
        .then(person => {
            res.status(200).json({'person': 'person in added successfully'});
        })
        .catch(err => {
            res.status(400).send("unable to save to database");
        });
});


personRoutes.route('/').get((req, res) =>{
    Person.find((err, persons)=>{
        if(err){
            console.log(err);
        }
        else {
            res.json(persons);
        }
    });
});


personRoutes.route('/edit/:id').get((req, res)=> {
    let id = req.params.id;
    Person.findById(id,  (err, data)=>{
        res.json(data);
    });
});


personRoutes.route('/update/:id').post((req, res)=> {
    Person.findById(req.params.id, (err, person) =>{
        console.log(person);
        console.log(req.params.id);

        if (!person)
            res.status(404).send("data is not found");
        else {
            console.log(person);
            person.name = req.body.name;
            person.company = req.body.company;
            person.age = req.body.age;

            person.save().then(data => {
                res.json('Update complete');
            })
                .catch(err => {
                    res.status(400).send("unable to update the database");
                });
        }
    });
});


personRoutes.route('/delete/:id').delete( (req, res) =>{
    // Person.findByIdAndRemove({_id: req.params.id},(err, person)=>{
    //     if(err) res.json(err);
    //     else res.json('Successfully removed');
    // });

		Person.findByIdAndDelete({_id: req.params.id},(err, person)=>{
            if(err) res.json(err);
            else res.json('Successfully removed');
        });
});

module.exports = personRoutes;