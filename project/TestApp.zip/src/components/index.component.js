import React, {Component} from 'react';
import { Link } from 'react-router-dom';
import { connect } from "react-redux";
import 'bootstrap/dist/css/bootstrap.min.css';
import { requestApiData, deleteApiData } from "../actions/actions";

class Index extends Component {
    delete = (id) =>{
        this.props.deleteApiData(id);

    }

    componentDidMount() {
        this.props.requestApiData();
    }


    person = (x, i) =>
        <tbody key={x._id}>
            <tr>
                <td>{x.name}</td>
                <td>{x.company}</td>
                <td>{x.age}</td>
                <td>
                    <button onClick={() => this.delete(x._id)} className="btn btn-danger">Delete</button>
                </td>
                <td>
                    <Link to={"/edit/"+ x._id} className="btn btn-primary" >Edit</Link>
                </td>
            </tr>
        </tbody>

    render() {
        const { data } = this.props;
        return data.length
            ? <div >
                <h1>List Data Table</h1>
                <table className="table table-striped" style={{ marginTop: 20 }}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Age</th>
                        </tr>
                    </thead>
                    {data.map(this.person)}
                </table>
            </div>
            : <h1>loading...</h1>;
    }
}

const mapStateToProps = state => ({ data: state.data });

const mapDispatchToProps = {
    requestApiData,
    deleteApiData
}

export default connect(mapStateToProps, mapDispatchToProps)(Index);