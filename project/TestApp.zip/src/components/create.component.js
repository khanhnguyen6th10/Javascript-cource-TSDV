import React, {Component} from 'react';
import { connect } from "react-redux";
import 'bootstrap/dist/css/bootstrap.min.css';
import { postApiData } from "../actions/actions";

class Create extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            company: '',
            age:''
        }
    }

    onChangeName = (e) =>{
        this.setState({
            name: e.target.value
        });
    }

    onChangeCompany = (e) =>{
        this.setState({
            company: e.target.value
        });
    }

    onChangeAge = (e) =>{
        this.setState({
            age: e.target.value
        });
    }

    onSubmit = (e) =>{
        e.preventDefault();

        const obj = {
            name: this.state.name,
            company: this.state.company,
            age: this.state.age
        };
        console.log(obj);
        this.props.postApiData(obj);

        this.setState({
            name: '',
            company: '',
            age: ''
        })
    }

    render() {
        return (
            <div style={{marginTop: 10}}>
                <h3>Add New Person</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Person Name: </label>
                        <input type="text" required className="form-control"
                               value={this.state.name}
                               onChange={this.onChangeName}
                        />
                    </div>
                    <div className="form-group">
                        <label>Company Name: </label>
                        <input type="text" required className="form-control" value={this.state.company}
                               onChange={this.onChangeCompany}/>
                    </div>
                    <div className="form-group">
                        <label>Age: </label>
                        <input type="text" required className="form-control" value={this.state.age}
                               onChange={this.onChangeAge}/>
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Register Person" className="btn btn-primary"/>
                    </div>
                </form>
            </div>
        )
    }
}
const mapStateToProps = state => ({ data: state.data });

const mapDispatchToProps = {
    postApiData
}

export default connect(mapStateToProps, mapDispatchToProps)(Create);