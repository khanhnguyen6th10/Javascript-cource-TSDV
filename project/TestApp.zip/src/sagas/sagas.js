import { call, put, takeEvery } from "redux-saga/effects";
import { requestApiData, 
  receiveApiData, 
  POST_API_DATA, 
  REQUEST_API_DATA,
  DELETE_API_DATA, 
  DETAIL_API_DATA, 
  UPDATE_API_DATA } from "../actions/actions";
import { fetchData, fetchPostData, fetchDetailData, fetchUpdateData } from "../api";



function* getApiData(action) {
  try {
    const data = yield call(fetchData);
    yield put(receiveApiData(data));
  } catch (e) {
    console.log(e);
  }
};

function* postApiData({payload}){
  try {
    const data = yield call(fetchPostData, payload);
    yield put(receiveApiData(data));
  } catch (e) {
    console.log(e);
  }
};

function* deleteApiData({payload}){
  try {
    yield put(requestApiData());
  } catch (e) {
    console.log(e);
  }
};
function* detailApiData({payload}){
  try {
    const data = yield call(fetchDetailData, payload);
    yield put(receiveApiData(data));
  } catch (e) {
    console.log(e);
  }
};

function* updateApiData({payload}){;
  try {
    console.log(payload);
    const data = yield call(fetchUpdateData, payload);
    console.log(data);
    yield put(requestApiData());
  } catch (e) {
    console.log(e);
  }
};
export default function* mySaga() {
  yield takeEvery(REQUEST_API_DATA, getApiData);
  yield takeEvery(POST_API_DATA, postApiData);
  yield takeEvery(DELETE_API_DATA, deleteApiData);
  yield takeEvery(DETAIL_API_DATA, detailApiData);
  yield takeEvery(UPDATE_API_DATA, updateApiData);
}

