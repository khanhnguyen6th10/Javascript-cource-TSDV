import { combineReducers } from "redux";

import data from "./data";

export default combineReducers({
  data
});
