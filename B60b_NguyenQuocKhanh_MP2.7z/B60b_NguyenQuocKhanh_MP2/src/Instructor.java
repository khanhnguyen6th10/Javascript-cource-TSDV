import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Instructor extends Person {
	private int Salary;
	private int CourseID;
	private final Scanner input = new Scanner(System.in);
	private ArrayList<Instructor> listInstructor = new ArrayList<Instructor>();

	public Instructor() {

	}

	public String toString() {
		return "[" + super.toString() + "Salary : " + Salary + ", Course ID : " + CourseID + ",]";
	}

	public Instructor(int ID, String Name, String DOB, String Address, int Salary, int CourseID) {
		super(ID, Name, DOB, Address);
		this.Salary = Salary;
		this.CourseID = CourseID;

	}

	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	public int getCourseID() {
		return CourseID;
	}

	public void setCourseID(int courseID) {
		CourseID = courseID;
	}

	public ArrayList<Instructor> InsertInstructor() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap so luong nhan vien : ");
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			System.out.println("Moi nhap vao thong tin giao vien thu " + (i + 1));
			System.out.print("Moi nhap ID: ");
			int ID = input.nextInt();
			input.nextLine();
			System.out.print("moi nhap ten: ");
			String Name = input.nextLine();
			System.out.print("Moi nhap DOB: ");
			String DOB = input.nextLine();
			System.out.print("Moi nhap Address: ");
			String Address = input.nextLine();
			System.out.print("Moi nhap vao Salary: ");
			int Salary = input.nextInt();
			input.nextLine();
			System.out.print("Moi nhap vao CourseID: ");
			int CourseID = input.nextInt();
			input.nextLine();
			Instructor instructor = new Instructor(ID, Name, DOB, Address, Salary, CourseID);
			listInstructor.add(instructor);

		}
		return listInstructor;
	}
	public void test() {
		for (int i = 0; i < listInstructor.size() - 1; i++) {
			for (int j = i + 1; j < listInstructor.size(); j++) {
				if (listInstructor.get(j).getID() == listInstructor.get(i).getID()) {
					listInstructor.remove(j);
				}
			}
		}
	}

	public void ShowListInstructor() {
		for (int i = 0; i < listInstructor.size(); i++) {
			System.out.println("Instructor thu " + (i + 1) + ":" + listInstructor.get(i).toString());
		}
	}
	

	public void removeInstructor() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap ID instructor can xoa : ");
		int ID = sc.nextInt();
		if (!listInstructor.isEmpty()) {
			for (int i = 0; i < listInstructor.size(); i++) {
				if (listInstructor.get(i).getID() == ID) {
					listInstructor.remove(i);
				}
			}
		} else {
			System.out.println("Instructor khong ton tai!!!");
		}
	}
}
