
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Course {
	private int CourseID;
	private String CourseName;
	private int CourseScore;
	private ArrayList<Course> list = new ArrayList<Course>();
	private Scanner sc = new Scanner(System.in);

//	ArrayList list = new ArrayList()
	public Course() {

	}

	public Course(int CourseID, String CourseName) {
		this.CourseID = CourseID;
		this.CourseName = CourseName;
	}

	public int getCourseID() {
		return CourseID;
	}

	public ArrayList<Course> getList() {
		return list;
	}

	public void setList(ArrayList<Course> list) {
		this.list = list;
	}

	public Scanner getsc() {
		return sc;
	}

	public void setsc(Scanner sc) {
		this.sc = sc;
	}

	public void setCourseID(int courseID) {
		CourseID = courseID;
	}

	public String getCourseName() {
		return CourseName;
	}

	public void setCourseName(String courseName) {
		CourseName = courseName;
	}

	public String toString() {
		return "Course [Course ID : " + CourseID + ", Course Name : " + CourseName + "]";
	}

	public ArrayList<Course> addTrainedCourse() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap so luong Course : ");
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			System.out.print("moi nhap ID: ");
			int CourseID = sc.nextInt();
			sc.nextLine();
			System.out.print("moi nhap ten: ");
			String CourseName = sc.nextLine();
			Course Course = new Course(CourseID, CourseName);
			list.add(Course);
		}
		return list;
	}

	public void ShowListCourse() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Khoa hoc thu " + (i + 1) + ":" + list.get(i).toString());
		}
	}
	
	public void test() {
		for(int i=0;i<list.size()-1;i++) {
			for(int j=i+1;j<list.size();j++) {
				if(list.get(j).getCourseID()==list.get(i).getCourseID()) {
					list.remove(j);
				}
			}
		}
	}

	public void removeCourse() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap ID course can xoa : ");
		int CourseID = sc.nextInt();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getCourseID() == CourseID) {
				list.remove(i);
			}else {
				System.out.println("Course khong ton tai!!!");
			}
		}

	}

	public void editCourse() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap ID course can chinh sua : ");
		int CourseID = sc.nextInt();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getCourseID() == CourseID) {
				list.get(i).toString();
				System.out.println("Thay Doi Ten khoa hoc: ");
				String CourseName = sc.next();
				list.get(i).setCourseName(CourseName);
			}else {
				System.out.println("Course khong ton tai!!!");
			}
		}
	}
}
