import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Course course = new Course();
		Trainee trainee = new Trainee();
		Instructor instructor = new Instructor();
		Scanner input = new Scanner(System.in);
		boolean cont = true;
		do {
			System.out.println("Chọn chức năng : [1- 10]");
			System.out.println("1. Them Trained Course");
			System.out.println("2. Them trainee");
			System.out.println("3. Them instructor");
			System.out.println("4. Xoa course");
			System.out.println("5. Xoa trainee");
			System.out.println("6. Xoa instructor");
			System.out.println("7. Chinh sua course"); 
			System.out.println("8. Hien thi trainee");
			System.out.println("9. Hien thi course");
			System.out.println("10. Hien thi instructor");
			int chon = input.nextInt();
			switch (chon) {
			case 1:
				course.addTrainedCourse();
				course.test();
				
				break;
			case 2:
				trainee.addTrainee();
				trainee.test();
				
				break;
			case 3:
				instructor.InsertInstructor();
				instructor.test();
				break;
			case 4:
				course.removeCourse();
				break;
			case 5:
				trainee.removeTrainee();
				break;
			case 6:
				instructor.removeInstructor();
				break;
			case 7:
				course.editCourse();
				break;
			case 8:
				trainee.ShowListTrainee();
				break;
			case 9:
				course.ShowListCourse();
				break;
			case 10:
				instructor.ShowListInstructor();
				break;
			default:
				cont = false;
				break;
			}
		} while (cont);
		
		
		
//		course.addTrainedCourse();
//		course.test();
//		course.ShowListCourse();
//		course.removeCourse(CourseID);
//		course.editCourse(CourseID);
		
//		trainee.addTrainee();
//		trainee.test();
//		trainee.ShowListTrainee();
//		trainee.removeTrainee();
//		trainee.ShowListTrainee();
		
		
		
//		instructor.InsertInstructor(1);
//		instructor.test();
//		instructor.ShowListInstructor();
//		instructor.removeInstructor(3);
		}
}
