import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




public class Trainee extends Person{
	private int IdInstructor;
	private int CourseID;
	private int CourseScore;
	private ArrayList<Trainee> list = new ArrayList<Trainee>();
	private final Scanner input = new Scanner(System.in);

	public Trainee() {

	}

	public Trainee(int ID, String Name, String DOB, String Address, int IdInstructor, int CourseID, int CourseScore) {
		super(ID, Name, DOB, Address);
		this.IdInstructor = IdInstructor;
		this.CourseID = CourseID;
		this.CourseScore = CourseScore;
	}

	public int getIdInstructor() {
		return IdInstructor;
	}

	public void setIdInstructor(int idInstructor) {
		IdInstructor = idInstructor;
	}

	public int getCourseID() {
		return CourseID;
	}

	public void setCourseID(int courseID) {
		CourseID = courseID;
	}

	public int getCourseScore() {
		return CourseScore;
	}

	public void setCourseScore(int courseScore) {
		CourseScore = courseScore;
	}

	public String toString() {
		return "Trainee [" + super.toString() + "ID Instructor : " + IdInstructor + ", Course ID : " + CourseID
				+ ", Course Score : " + CourseScore + "]";
	}

	public ArrayList<Trainee> addTrainee() {
		System.out.println("moi ban nhap vao so luong: ");
		int n = input.nextInt();
		input.nextLine();

		for (int i = 0; i < n; i++) {
			System.out.println("Moi ban nhap thong tin Trainee thu " + (i + 1));
			System.out.print("Moi nhap ID: ");
			int ID = input.nextInt();
			input.nextLine();
			System.out.print("Moi nhap ten: ");
			String Name = input.nextLine();
			System.out.print("Moi nhap DOB: ");
			String DOB = input.nextLine();
			System.out.print("Moi nhap Address: ");
			String Address = input.nextLine();
			System.out.print("Moi nhap vao ID Instructor: ");
			int IdInstructor = input.nextInt();
			input.nextLine();
			System.out.print("Moi nhap vao ID Course: ");
			int CourseID = input.nextInt();
			input.nextLine();
			System.out.print("Moi nhap Score Course: ");
			int CourseScore = input.nextInt();
			input.nextLine();
			Trainee trainee = new Trainee(ID, Name, DOB, Address, IdInstructor, CourseID, CourseScore);
			list.add(trainee);
		}
		return list;
	}

	public void test() {
		for (int i = 0; i < list.size() - 1; i++) {
			for (int j = i + 1; j < list.size(); j++) {
				if (list.get(j).getID() == list.get(i).getID()) {
					list.remove(j);
				}
				
			}
		}
	}

	public void ShowListTrainee() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Thong tin Trainee thu " + (i + 1) + ":" + list.get(i).toString());
		}
	}

	public void removeTrainee() {
		System.out.print("moi ban nhap ID: ");
		int ID = input.nextInt();
		input.nextLine();
		if (!list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getID() == ID) {
					list.remove(i);
				}
			}
		} else {
			System.out.println("Trainee khong ton tai!!!");
		}
	}

	
	
}
