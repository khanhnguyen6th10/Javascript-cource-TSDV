package baitapthuattoan;

public class HanoiTower {
	public int count = 0;
	public void move(int n, char A, char B, char C) {
		if(n==1) {
			count++;
			System.out.println("step " + count + " move " + A + " -> " + B);
		} else {
			move(n-1,A,C,B);
			move(1,A,B,C);
			move(n-1,C,B,A);
		}
	}
	public static void main(String[] args) {
		HanoiTower app = new HanoiTower();
		app.move(4, 'A', 'B', 'C');
	}
}

