package baitapthuattoan;

public class Phuongtrinh {
	private int n;
	private int M;
	private int [] x;
	private int T;
	private boolean check(int v, int k) {
		if (k==n) {
			return T + v == M;
		}else
		return T+v <= M;
	}
	private void solution() {
		for(int i = 1; i<=n; i++) System.out.print(x[i] + "");
		System.out.println();
	}
	private void TRY(int k) {
		for (int v = 1; v<= M; v++) {
			if(check(v,k)) {
				x[k] = v;
				T = T + v;
				if (k ==n) solution();
				else TRY(k+1);
				T = T - v;
			}
		}
	}
	public void solve(int n, int M) {
		this.n = n;
		this.M = M;
		x= new int[n+1];
		T = 0;
		TRY(1);
		
	}
	public static void main(String[] args) {
		Phuongtrinh app = new Phuongtrinh();
		app.solve(3, 5);
	}
}
