package baitapthuattoan;

public class Hoanvi {
	private int n;
	private int[] x;
	private boolean[] xh;
	private boolean check(int v, int k) {
		return true;
		
	}
	private void solution() {
		
	}
	private void TRY(int k) {
		
	}
	public void solve(int n, int M) {
		this.n = n;
		x= new int[n+1];
		TRY(1);
		
	}
	public static void main(String[] args) {
		
	}
}
