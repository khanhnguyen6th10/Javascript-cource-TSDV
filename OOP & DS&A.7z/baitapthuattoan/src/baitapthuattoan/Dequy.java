package baitapthuattoan;

public class Dequy {
	public int[][] M;
	public int f(int n) {
		if (n==1) {
			return 1;
		}
		return n + f(n-1);
	}
	public int C(int k, int n) {
		if (k == 0 || k == n) {
			M[k][n] = 1;
		}else {
			if (M[k][n] == -1) {
				M[k][n] = C(k, n-1) + C(k-1, n-1);
			}
		}
		return M[k][n];
	}
	public void init() {
		M = new int[100][100];
		for (int i = 0; i < M.length; i++) {
			for (int j = 0; j < M.length; j++) {
				M[i][j] = -1;
			}
		}
	}
	public static void main(String[] args) {
		Dequy recursive1 = new Dequy();
		System.out.println(recursive1.f(5));
		double t0 = System.currentTimeMillis();
		recursive1.init();
		System.out.println(recursive1.C(30, 36));
		double t1 = System.currentTimeMillis() - t0;
		System.out.println("execute time = " + (t1*0.001) + "(s)");
	}
}

