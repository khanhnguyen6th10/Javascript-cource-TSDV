//package baitapthuattoan;
//
//public class Lienkenhiphan {
//	private int n;
//	private int[] x;
//	private int count = 0;
//	private boolean check(int v, int k) {
////		c1
//		if (k == 1) return true;
//		if (v == 1 && x[k-1] == 1) return false;
////		c2
////		return v + x[k-1] < 2; 
//		return true;
//	}
//	private void solution() {
//		count ++;
//		System.out.print("Solution" + count + ": ");
//		for(int i = 1; i<= n; i++) {
//			System.out.print(x[i] + " ");
//			}
//		System.out.println();
//	}
//	private void TRY(int k) {
//		for (int v=0; v<= 1; v++) {
//			if(check(v,k)) {
//				x[k] = v;
//				if (k ==n) solution();
//				else {
//					TRY(k+1);
//				}
//			}
//		}
//	}
//	public void solve(int n) {
//		this.n = n;
//		x = new int[n+1];
//		count = 0;
//		TRY(1);
//	}
//	public static void main(String[] args) {
//		Lienkenhiphan app = new Lienkenhiphan();
//		app.solve(3);
//		app.TRY(2);
//	}
//}
