import java.util.Date;

public class Instructor extends Person {
	 private int Salary;
	 private int CourseID;
	 public Instructor(int ID, String name, Date dob, String address,int Salary, int CourseID)
	    {
		 super (ID,name,dob,address);
	       this.Salary = Salary;
	       this.CourseID = CourseID;
	    }
	 public int getSalary()                
	    {
	        return Salary;
	    }
	 public int getCourseID()                
	    {
	        return CourseID;
	    }
	 public int setSalary()                
	    {
	        return Salary;
	    }
	 public int setCourseID()                
	    {
	        return CourseID;
	    }
}
