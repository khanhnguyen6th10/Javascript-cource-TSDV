
public class Course {
	private int CourseID;
	private String CourseName;
	 public Course(int CourseID, String CourseName)
	    {
	       this.CourseID = CourseID;
	       this.CourseName = CourseName;
	    }
	 public int getCourseID()                
	    {
	        return CourseID;
	    }
	 public String getCourseName()                
	    {
	        return CourseName;
	    }
	 public int setCourseID()                
	    {
	        return CourseID;
	    }
	 public String setCourseName()                
	    {
	        return CourseName;
	    }
}
