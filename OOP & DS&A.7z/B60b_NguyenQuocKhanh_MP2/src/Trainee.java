import java.util.Date;
import java.util.Scanner;

public class Trainee extends Person{
	private int InstructorID;
	private int CourseID;
	private int CourseScore;
	public Trainee(int ID, String name, Date dob, String address,int InstructorID, int CourseID, int CourseScore)
	    {
		   super (ID,name,dob,address);
	       this.InstructorID = InstructorID;
	       this.CourseID = CourseID;
	       this.CourseScore = CourseScore;
	    }
	 public int getInstructorID()                
	    {
	        return InstructorID;
	    }
	 public int getCourseID()                
	    {
	        return CourseID;
	    }
	 public int getCourseScore()                
	    {
	        return CourseScore;
	    }
	 public int setInstructorID()                
	    {
	        return InstructorID;
	    }
	 public int setCourseID()                
	    {
	        return CourseID;
	    }
	 public int setCourseScore()                
	    {
	        return CourseScore;
	    }
	 
	 
	 public void addTrainedCourse() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Insert ID of Instructor : ");
	        InstructorID = scanner.nextInt();
	        System.out.print("Insert ID of Course : ");
	        CourseID = scanner.nextInt();
	        System.out.print("Insert Score of Course : ");
	        CourseScore = scanner.nextInt();
	    }
	 
	
}
