
import java.util.Date;


public class Person {
	 private int ID;
	 private String name;
	 private Date dob;
	 private String address;
	 public Person(int ID, String name, Date dob, String address)
	    {
	       this.ID = ID;
	       this.name = name;
	       this.dob = dob;
	       this.address = address;
	    }
	 public int getID()                
	    {
	        return ID;
	    }
	 public String getName()                
	    {
	        return name;
	    }
	 public Date getDOB()                
	    {
	        return dob;
	    }
	 public String getAddress()                
	    {
	        return address;
	    }
	 public int setID()                
	    {
	        return ID;
	    }
	 public String setName()                
	    {
	        return name;
	    }
	 public Date setDOB()                
	    {
	        return dob;
	    }
	 public String setAddress()                
	    {
	        return address;
	    }
	 
	 

}
